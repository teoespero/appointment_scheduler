module teoespero.jappointment {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens teoespero.jappointment to javafx.fxml;
    exports teoespero.jappointment;
    exports teoespero.jappointment.Controllers;
    opens teoespero.jappointment.Controllers to javafx.fxml;
    exports teoespero.jappointment.Model;
    opens teoespero.jappointment.Model to javafx.fxml;
}