Author: Teodulfo Espero
Student ID: 000891230
Email: tespero@wgu.edu

Application Version: 1.0
Date: 05/31/2023

IDE: IntelliJ Community 2022.3.2
JDK: 17.0.2
JavaFX: 17.0.2
MySQL Connector Driver Version: 8.0.26

The JAppointment Application is a Java Based application using the JavaFX framework that provides the 
user with the following capabilities:

	A) Manage Appointments
		- Search for an appointment
		- Add a new appointment
		- Modify existing appointment
		- Delete an existing appointment
	B) Manage Customers
		- Add new customers
		- Update customer records
		- Delete customer records. Note that all appointments associated with the customer will also be deleted.
	C) Run system generated reports about appointments.

---------------------------------------------------------------------------------------------------------------------------------

Instructions:

	1. 	Make sure that JDK 11 or higher is installed (https://www.oracle.com/java/technologies/downloads/#java11).
	2. 	Make sure that JavaFX 17 or higher is installed and configured (https://gluonhq.com/products/javafx/).
	3. 	Open the Main project file using IntelliJ IDEA (https://www.jetbrains.com/idea/download/other.html).
	4. 	Make sure that the required libraries are referenced correctly, information on referencing these files can be viewed from 
		the links below or from the IntelliJ website:

			- JavaFX (https://wgu.hosted.panopto.com/Panopto/Pages/Viewer.aspx?id=74c2fa52-c8d7-453b-b6e1-abe9014655fb)

			- MySQL Connection (https://wgu.webex.com/recordingservice/sites/wgu/recording/e0de37fdf5471039aefd00505681be2e/playback)

	5. 	From the main menu, click on Run > Run JAppointment
	6. 	Log into application using the following credentials:
 		
			Username: admin 
			Password: admin

Additional Notes:

	- 	Language translation is provided in English, French and German for the Login screen only. Translated words were 
		sourced from Google translate, and the developer has no other means of verifying the accuracy of the translation 
		in terms of grammar and usage.

	- 	The 15 minute appointment reminder feature is user-specific.

	- 	The Appointment By Location Report is the additional report that fulfills section A.3.f.

Lambda Expressions:

	Lambda expression use can be found in the following classes:

	-	CustomersScreController.Java
		Location: src\main\java\teoespero\jappointment\Controllers
		Method: initialize
		Description: The expressions are used to pre-populate the customer grid on the Customer form.

	-	MonthByTypeReportScreController.Java
		Location: src\main\java\teoespero\jappointment\Controllers
		Method: generateJReport
		Description: The expressions are used to provides the logic and control needed to display information on 
				 the report grid.

JavaDoc Location: src\JavaDoc

